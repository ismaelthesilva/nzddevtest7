<?php
/**
 * Admin page file.
 *
 * @package WPE_Update_Source_Selector
 *
 * This is the main entry point for the settings admin page.
 */

namespace WPE_Update_Source_Selector;

require 'header.php';

require 'content.php';
