<?php
namespace wpengine\cache_plugin;

abstract class ClearAllCacheStatus {
	const DEFAULT = 0;
	const SUCCESS = 1;
	const ERROR   = 2;
}
