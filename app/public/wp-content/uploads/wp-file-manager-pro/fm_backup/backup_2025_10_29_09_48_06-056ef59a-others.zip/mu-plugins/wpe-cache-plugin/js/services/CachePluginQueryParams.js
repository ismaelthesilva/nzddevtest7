export default {
    notification: 'notification',
};
