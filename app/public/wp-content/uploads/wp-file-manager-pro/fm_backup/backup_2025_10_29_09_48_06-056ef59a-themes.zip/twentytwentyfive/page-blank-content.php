<?php
/*
Template Name: Blank Content Only
Template Post Type: page
*/
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); // keep this so block styles and plugins load ?>
</head>
<body <?php body_class('template-blank-content'); ?>>
  <?php
  if ( have_posts() ) :
    while ( have_posts() ) : the_post();
      the_content(); // only the page content
    endwhile;
  endif;
  ?>
  <?php wp_footer(); // keep this so scripts load ?>
</body>
</html>