CREATE DATABASE IF NOT EXISTS `wp_nzddevtest7`;

USE `wp_nzddevtest7`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint unsigned NOT NULL DEFAULT '0',
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_comments` VALUES (1,1,"A WordPress Commenter","wapuu@wordpress.example","https://wpengine.com/","","2025-10-16 04:16:33","2025-10-16 04:16:33","Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com/\">Gravatar</a>.",0,1,"","comment",0,0);


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint unsigned NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES (1,"cron","a:14:{i:1761731788;a:1:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1761733588;a:1:{s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1761733594;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1761736396;a:1:{s:49:\"WPEngineSecurityAuditor_Scans_fingerprint_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1761760711;a:1:{s:46:\"WPEngineSecurityAuditor_Scans_fingerprint_core\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1761767013;a:1:{s:48:\"WPEngineSecurityAuditor_Scans_fingerprint_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1761769593;a:2:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1761769594;a:1:{s:39:\"WPEngineSecurityAuditor_Scans_scheduler\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1761770863;a:3:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:21:\"wp_update_user_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1761770867;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1761773188;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1762288449;a:1:{s:27:\"acf_update_site_health_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}i:1762289397;a:1:{s:30:\"wp_delete_temp_updater_backups\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}","on"),
(2,"siteurl","https://nzddevtest7.wpenginepowered.com","on"),
(3,"home","https://nzddevtest7.wpenginepowered.com","on"),
(4,"blogname","NZD Test 7","on"),
(5,"blogdescription","Test Site","on"),
(6,"users_can_register",0,"on"),
(7,"admin_email","adam@nzdigital.co.nz","on"),
(8,"start_of_week",1,"on"),
(9,"use_balanceTags",0,"on"),
(10,"use_smilies",1,"on"),
(11,"require_name_email",1,"on"),
(12,"comments_notify",1,"on"),
(13,"posts_per_rss",10,"on"),
(14,"rss_use_excerpt",0,"on"),
(15,"mailserver_url","mail.example.com","on"),
(16,"mailserver_login","login@example.com","on"),
(17,"mailserver_pass","","on"),
(18,"mailserver_port",110,"on"),
(19,"default_category",1,"on"),
(20,"default_comment_status","open","on"),
(21,"default_ping_status","open","on"),
(22,"default_pingback_flag",0,"on"),
(23,"posts_per_page",10,"on"),
(24,"date_format","F j, Y","on"),
(25,"time_format","g:i a","on"),
(26,"links_updated_date_format","F j, Y g:i a","on"),
(27,"comment_moderation",0,"on"),
(28,"moderation_notify",1,"on"),
(29,"permalink_structure","","on"),
(30,"rewrite_rules","","on"),
(31,"hack_file",0,"on"),
(32,"blog_charset","UTF-8","on"),
(33,"moderation_keys","","off"),
(34,"active_plugins","a:4:{i:0;s:34:\"advanced-custom-fields-pro/acf.php\";i:1;s:39:\"disable-gutenberg/disable-gutenberg.php\";i:2;s:27:\"js_composer/js_composer.php\";i:3;s:39:\"wp-file-manager/file_folder_manager.php\";}","on"),
(35,"category_base","","on"),
(36,"ping_sites","https://rpc.pingomatic.com/","on"),
(37,"comment_max_links",2,"on"),
(38,"gmt_offset",0,"on"),
(39,"default_email_category",1,"on"),
(40,"recently_edited","","off"),
(41,"template","twentytwentyfive","on"),
(42,"stylesheet","twentytwentyfive","on"),
(43,"comment_registration",0,"on"),
(44,"html_type","text/html","on"),
(45,"use_trackback",0,"on"),
(46,"default_role","subscriber","on"),
(47,"db_version",60421,"on"),
(48,"uploads_use_yearmonth_folders",1,"on"),
(49,"upload_path","","on"),
(50,"blog_public",0,"on"),
(51,"default_link_category",2,"on"),
(52,"show_on_front","page","on"),
(53,"tag_base","","on"),
(54,"show_avatars",1,"on"),
(55,"avatar_rating","G","on"),
(56,"upload_url_path","","on"),
(57,"thumbnail_size_w",150,"on"),
(58,"thumbnail_size_h",150,"on"),
(59,"thumbnail_crop",1,"on"),
(60,"medium_size_w",300,"on"),
(61,"medium_size_h",300,"on"),
(62,"avatar_default","mystery","on"),
(63,"large_size_w",1024,"on"),
(64,"large_size_h",1024,"on"),
(65,"image_default_link_type","none","on"),
(66,"image_default_size","","on"),
(67,"image_default_align","","on"),
(68,"close_comments_for_old_posts",0,"on"),
(69,"close_comments_days_old",14,"on"),
(70,"thread_comments",1,"on"),
(71,"thread_comments_depth",5,"on"),
(72,"page_comments",0,"on"),
(73,"comments_per_page",50,"on"),
(74,"default_comments_page","newest","on"),
(75,"comment_order","asc","on"),
(76,"sticky_posts","a:0:{}","on"),
(77,"widget_categories","a:0:{}","on"),
(78,"widget_text","a:0:{}","on"),
(79,"widget_rss","a:0:{}","on"),
(80,"uninstall_plugins","a:0:{}","off"),
(81,"timezone_string","","on"),
(82,"page_for_posts",0,"on"),
(83,"page_on_front",2,"on"),
(84,"default_post_format",0,"on"),
(85,"link_manager_enabled",0,"on"),
(86,"finished_splitting_shared_terms",1,"on"),
(87,"site_icon",0,"on"),
(88,"medium_large_size_w",768,"on"),
(89,"medium_large_size_h",0,"on"),
(90,"wp_page_for_privacy_policy",3,"on"),
(91,"show_comments_cookies_opt_in",1,"on"),
(92,"admin_email_lifespan",1776140192,"on"),
(93,"disallowed_keys","","off"),
(94,"comment_previously_approved",1,"on"),
(95,"auto_plugin_theme_update_emails","a:0:{}","off"),
(96,"auto_update_core_dev","enabled","on"),
(97,"auto_update_core_minor","enabled","on"),
(98,"auto_update_core_major","enabled","on"),
(99,"wp_force_deactivated_plugins","a:0:{}","on"),
(100,"wp_attachment_pages_enabled",0,"on"),
(101,"initial_db_version",60421,"on"),
(102,"wp_user_roles","a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}","on"),
(103,"fresh_site",0,"off"),
(104,"user_count",3,"off"),
(105,"widget_block","a:6:{i:2;a:1:{s:7:\"content\";s:19:\"<!-- wp:search /-->\";}i:3;a:1:{s:7:\"content\";s:154:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Posts</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->\";}i:4;a:1:{s:7:\"content\";s:227:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Recent Comments</h2><!-- /wp:heading --><!-- wp:latest-comments {\"displayAvatar\":false,\"displayDate\":false,\"displayExcerpt\":false} /--></div><!-- /wp:group -->\";}i:5;a:1:{s:7:\"content\";s:146:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->\";}i:6;a:1:{s:7:\"content\";s:150:\"<!-- wp:group --><div class=\"wp-block-group\"><!-- wp:heading --><h2>Categories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->\";}s:12:\"_multiwidget\";i:1;}","auto"),
(106,"sidebars_widgets","a:7:{s:19:\"wp_inactive_widgets\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}s:13:\"array_version\";i:3;}","auto"),
(107,"widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(108,"widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(109,"widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(110,"widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(111,"widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(112,"widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(113,"widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(114,"widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(115,"widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(116,"widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(117,"widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(118,"widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(119,"widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(120,"widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(121,"widget_wpe_powered_by_widget","a:1:{s:12:\"_multiwidget\";i:1;}","auto"),
(122,"theme_mods_twentytwentyfive","a:4:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1760588295;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";}s:9:\"sidebar-2\";a:2:{i:0;s:7:\"block-5\";i:1;s:7:\"block-6\";}}}s:19:\"wp_classic_sidebars\";a:3:{s:8:\"footer-1\";a:11:{s:4:\"name\";s:17:\"Footer - Column 1\";s:2:\"id\";s:8:\"footer-1\";s:11:\"description\";s:64:\"Widgets added here will appear in the left column of the footer.\";s:5:\"class\";s:0:\"\";s:13:\"before_widget\";s:39:\"<section id=\"%1$s\" class=\"widget %2$s\">\";s:12:\"after_widget\";s:10:\"</section>\";s:12:\"before_title\";s:25:\"<h3 class=\"widget-title\">\";s:11:\"after_title\";s:5:\"</h3>\";s:14:\"before_sidebar\";s:0:\"\";s:13:\"after_sidebar\";s:0:\"\";s:12:\"show_in_rest\";b:0;}s:8:\"footer-2\";a:11:{s:4:\"name\";s:17:\"Footer - Column 2\";s:2:\"id\";s:8:\"footer-2\";s:11:\"description\";s:66:\"Widgets added here will appear in the center column of the footer.\";s:5:\"class\";s:0:\"\";s:13:\"before_widget\";s:39:\"<section id=\"%1$s\" class=\"widget %2$s\">\";s:12:\"after_widget\";s:10:\"</section>\";s:12:\"before_title\";s:25:\"<h3 class=\"widget-title\">\";s:11:\"after_title\";s:5:\"</h3>\";s:14:\"before_sidebar\";s:0:\"\";s:13:\"after_sidebar\";s:0:\"\";s:12:\"show_in_rest\";b:0;}s:8:\"footer-3\";a:11:{s:4:\"name\";s:17:\"Footer - Column 3\";s:2:\"id\";s:8:\"footer-3\";s:11:\"description\";s:65:\"Widgets added here will appear in the right column of the footer.\";s:5:\"class\";s:0:\"\";s:13:\"before_widget\";s:39:\"<section id=\"%1$s\" class=\"widget %2$s\">\";s:12:\"after_widget\";s:10:\"</section>\";s:12:\"before_title\";s:25:\"<h3 class=\"widget-title\">\";s:11:\"after_title\";s:5:\"</h3>\";s:14:\"before_sidebar\";s:0:\"\";s:13:\"after_sidebar\";s:0:\"\";s:12:\"show_in_rest\";b:0;}}s:18:\"nav_menu_locations\";a:0:{}}","on"),
(124,"wpe_feature_flags","a:4:{s:29:\"showUpdateProviderHealthPanel\";b:1;s:23:\"showCurrentUpdateSource\";b:1;s:25:\"showUpdateSourceSelection\";b:1;s:19:\"allowSourceOverride\";b:1;}","auto"),
(125,"wpe_feature_flags_expiration",1761731542,"auto"),
(126,"recovery_keys","a:0:{}","off"),
(127,"wpe_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:62:\"https://wpe-downloads.wpengine.com/release/wordpress-6.8.3.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:62:\"https://wpe-downloads.wpengine.com/release/wordpress-6.8.3.zip\";s:10:\"no_content\";s:73:\"https://wpe-downloads.wpengine.com/release/wordpress-6.8.3-no-content.zip\";s:11:\"new_bundled\";s:74:\"https://wpe-downloads.wpengine.com/release/wordpress-6.8.3-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"6.8.3\";s:7:\"version\";s:5:\"6.8.3\";s:11:\"php_version\";s:6:\"7.2.24\";s:13:\"mysql_version\";s:5:\"5.5.5\";s:11:\"new_bundled\";s:3:\"6.7\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1761730677;s:15:\"version_checked\";s:5:\"6.8.3\";s:12:\"translations\";a:0:{}}","off"),
(133,"current_theme","Twenty Twenty-Five","auto"),
(134,"theme_switched","","auto"),
(135,"theme_mods_genesis-block-theme","a:3:{s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1760590724;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:5:{i:0;s:7:\"block-2\";i:1;s:7:\"block-3\";i:2;s:7:\"block-4\";i:3;s:7:\"block-5\";i:4;s:7:\"block-6\";}}}}","off"),
(136,"wpe_template","Genesis Blocks Free","auto"),
(139,"wpe_notices","a:0:{}","auto"),
(140,"wpe_notices_expiration",1761731542,"auto"),
(141,"genesis_blocks_has_content_to_migrate",0,"auto"),
(142,"can_compress_scripts",1,"on"),
(144,"finished_updating_comment_type",1,"auto"),
(145,"recently_activated","a:1:{s:33:\"genesis-blocks/genesis-blocks.php\";i:1760590740;}","off"),
(146,"wpesu-plugin-genesis-blocks-expiry",1760608368,"off"),
(147,"wpesu-plugin-genesis-blocks","{\n  \"name\": \"Genesis Blocks\",\n  \"slug\": \"genesis-blocks\",\n  \"version\": \"3.1.7\",\n  \"author\": \"<a href=\\\"https://www.studiopress.com/\\\">StudioPress</a>\",\n  \"author_profile\": \"https://profiles.wordpress.org/studiopress/\",\n  \"contributors\": {\n    \"dreamwhisper\": {\n      \"profile\": \"https://profiles.wordpress.org/dreamwhisper/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/aac0f5f2ee8f4ae47977c54f04e2b991?s=96&d=monsterid&r=g\",\n      \"display_name\": \"Jen Baumann\"\n    },\n    \"johnstonphilip\": {\n      \"profile\": \"https://profiles.wordpress.org/johnstonphilip/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/459d1a78b2c7c46729a175c372a9be4f?s=96&d=monsterid&r=g\",\n      \"display_name\": \"Phil Johnston\"\n    },\n    \"marksabbath\": {\n      \"profile\": \"https://profiles.wordpress.org/marksabbath/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/24a3f43146b18fc5c7a70ba233aa4c6b?s=96&d=monsterid&r=g\",\n      \"display_name\": \"marksabbath\"\n    },\n    \"mikeday\": {\n      \"profile\": \"https://profiles.wordpress.org/mikeday/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/4f6485b17a04a8ac5ee54dc8206f0663?s=96&d=monsterid&r=g\",\n      \"display_name\": \"Michael Day\"\n    },\n    \"mindctrl\": {\n      \"profile\": \"https://profiles.wordpress.org/mindctrl/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/1b31a4fe3905a88053a566b6037002d5?s=96&d=monsterid&r=g\",\n      \"display_name\": \"John Parris\"\n    },\n    \"modernnerd\": {\n      \"profile\": \"https://profiles.wordpress.org/modernnerd/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/fb9b76c6ed2685d4bd52a863a3cebdd2?s=96&d=monsterid&r=g\",\n      \"display_name\": \"Nick C\"\n    },\n    \"ryankienstra\": {\n      \"profile\": \"https://profiles.wordpress.org/ryankienstra/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/9056a7f3e47cce5f4f5c6bcf89cd8864?s=96&d=monsterid&r=g\",\n      \"display_name\": \"Ryan Kienstra\"\n    },\n    \"studiopress\": {\n      \"profile\": \"https://profiles.wordpress.org/studiopress/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/8232a7e34307d42f23d30267415d3a98?s=96&d=monsterid&r=g\",\n      \"display_name\": \"StudioPress\"\n    },\n    \"wpengine\": {\n      \"profile\": \"https://profiles.wordpress.org/wpengine/\",\n      \"avatar\": \"https://secure.gravatar.com/avatar/6d44461b684d2f3d8f6fcf3d657cb889?s=96&d=monsterid&r=g\",\n      \"display_name\": \"WP Engine\"\n    }\n  },\n  \"requires\": \"6.1\",\n  \"tested\": \"6.6\",\n  \"requires_php\": \"7.1\",\n  \"requires_plugins\": [],\n  \"rating\": 74,\n  \"ratings\": {\n    \"1\": 6,\n    \"2\": 1,\n    \"3\": 1,\n    \"4\": 1,\n    \"5\": 14\n  },\n  \"num_ratings\": 23,\n  \"support_url\": \"https://wordpress.org/support/plugin/genesis-blocks/\",\n  \"support_threads\": 3,\n  \"support_threads_resolved\": 0,\n  \"active_installs\": 100000,\n  \"last_updated\": \"2025-03-19 16:28:51 GMT\",\n  \"added\": \"2020-08-25\",\n  \"homepage\": \"https://studiopress.com/genesis-pro/\",\n  \"sections\": {\n    \"description\": \"<p>Genesis Blocks is a collection of page building blocks for the Gutenberg block editor. Building pages with the block editor and Genesis Blocks gives you more control to quickly create and launch any kind of site you want!</p>\\n<p>Installing the customizable Genesis Blocks plugin adds a collection of beautiful, site-building blocks to help you customize page layouts, increase engagement, and get results for your business. Genesis Blocks provides everything from customizable buttons, to beautifully-designed page sections and full-page layout designs via the Section &amp; Layout block.</p>\\n<p>Along with the blocks themselves, Genesis Blocks extends the content creation experience by providing a library of page sections and full-page layouts, all available from within the block editor.</p>\\n<h3>Create compelling content faster.</h3>\\n<p>Create and use content quickly with prebuilt and custom content sections and full-page layouts.</p>\\n<h3>Enhance the Gutenberg editor.</h3>\\n<p>Additional content blocks and the layout selector make it easy to get the most value out of the block-based editor.</p>\\n<h3>Genesis Blocks currently includes the following blocks to help you build content and pages quickly and effortlessly:</h3>\\n<ul>\\n<li>Section &amp; Layout Block</li>\\n<li>Advanced Columns Block</li>\\n<li>Newsletter Block</li>\\n<li>Pricing Block</li>\\n<li>Post Grid Block</li>\\n<li>Container Block</li>\\n<li>Testimonial Block</li>\\n<li>Inline Notice Block</li>\\n<li>Accordion Block</li>\\n<li>Share Icons Block</li>\\n<li>Call-To-Action Block</li>\\n<li>Spacer &amp; Divider Block</li>\\n<li>Author Profile Block</li>\\n<li>Drop Cap Block</li>\\n</ul>\\n<p>Breaking change: The Genesis Blocks Button block is deprecated in favor of the Core Buttons block.</p>\\n<p>When you open the block editor, this will automatically convert your Genesis Blocks Button blocks to the Core Buttons block.</p>\\n<p>This will not convert Button blocks if you don&#8217;t open the block editor.</p>\\n<p>You might see some styling changes, especially if you have custom styling for classes other than &#8216;gb-block-button&#8217;.</p>\\n<h3>Do more with Genesis Pro</h3>\\n<p>For those wanting to level-up with Genesis Blocks, a Genesis Pro subscription brings even richer tooling and a bigger library of sections and layouts.</p>\\n<ul>\\n<li>2 new blocks</li>\\n<li>26 pre-built full-page layouts</li>\\n<li>56 pre-built sections</li>\\n<li>Save &amp; reuse your own sections &amp; layouts</li>\\n<li>Advanced block-level user permissions</li>\\n<li>Access to and support for Genesis Framework &amp; all of our 35 StudioPress-made premium child themes.</li>\\n<li>Additional advanced features for the rest of the Genesis Product Suite</li>\\n</ul>\\n<p>Genesis Pro includes even more value for modern WordPress content creators, marketers, and developers. <a href=\\\"https://www.studiopress.com/genesis-pro/\\\" rel=\\\"nofollow ugc\\\">Learn more about Genesis Pro here</a>.</p>\\n<h3>Google AMP Support</h3>\\n<p>The Accelerated Mobile Pages (AMP) project is a publishing format created by Google to enhance site performance for mobile website users. AMP pages are specially designed for Google search users to quickly load website pages without using any extraneous data. Genesis Blocks has support for AMP built into each block!</p>\\n<h3>Help &amp; Docs</h3>\\n<p>User and developer docs for Genesis Blocks <a href=\\\"https://developer.wpengine.com/genesis-pro/\\\" rel=\\\"nofollow ugc\\\">can be found here</a>.</p>\\n\",\n    \"installation\": \"<p>This plugin can be installed directly from your site.</p>\\n<ol>\\n<li>Log in and navigate to _Plugins &rarr; Add New.</li>\\n<li>Type &#8220;Genesis Blocks&#8221; into the Search and hit Enter.</li>\\n<li>Locate the Genesis Blocks plugin in the list of search results and click <strong>Install Now</strong>.</li>\\n<li>Once installed, click the Activate link.</li>\\n</ol>\\n<p>It can also be installed manually.</p>\\n<ol>\\n<li>Download the Genesis Blocks plugin from WordPress.org.</li>\\n<li>Unzip the package and move to your plugins directory.</li>\\n<li>Log into WordPress and navigate to the Plugins screen.</li>\\n<li>Locate Genesis Blocks in the list and click the <em>Activate</em> link.</li>\\n</ol>\\n\",\n    \"faq\": \"\\n<dt id=\'can%20genesis%20blocks%20be%20used%20with%20any%20theme%3F\'>\\nCan Genesis Blocks be used with any theme?\\n</h4>\\n<p>\\n<p>Yes, you can use Genesis Blocks with any theme, but we recommend using one of the Gutenberg-ready StudioPress themes such as <a href=\\\"https://my.studiopress.com/themes/revolution/\\\" rel=\\\"nofollow ugc\\\">Revolution</a> for the best presentation. Both of these themes have beautiful styles built in specifically for Genesis Blocks.</p>\\n</p>\\n<dt id=\'do%20i%20need%20the%20new%20block%20editor%20to%20use%20genesis%20blocks%3F\'>\\nDo I need the new block editor to use Genesis Blocks?\\n</h4>\\n<p>\\n<p>Yes, you will need to have WordPress 5.3 or later installed to take advantage of Genesis Blocks.</p>\\n</p>\\n\\n\",\n    \"changelog\": \"<h4>3.1.7</h4><br />\\n* Fixed: Resolved deprecation notices for use of translation functions too early.<br />\\n<br />\\n<h4>3.1.6</h4><br />\\n* Security: Genesis Blocks now uses its own update mechanism from WP Engine servers.<br />\\n<br />\\n<h4>3.1.5</h4><br />\\n* Fixed: Escape exception output as prompted by Plugin Check. <br />\\n<br />\\n<h4>3.1.4</h4><br />\\n* Fixed: Security improvement for the sharing block.<br />\\n<br />\\n<h4>3.1.3</h4><br />\\n* Fixed: Minor security vulnerability.<br />\\n<br />\\n<h4>3.1.2</h4><br />\\n* Fixed: WP 6.5 compatibility problem with responsive font size controls.<br />\\n<br />\\n<h4>3.1.1</h4><br />\\n* Fixed: Prevent block errors in wp-admin/widgets.php and in the Customizer with block widgets.<br />\\n<br />\\n<h4>3.1.0</h4><br />\\n* Changed: Make the minimum required PHP version 7.1 again.<br />\\n* Fixed: Prevent JS error on changing Paragraph and Heading block fonts.<br />\\n<br />\\n<h4>3.0.1</h4><br />\\n* Changed: Bump the minimum required PHP version to 8.1.<br />\\n<br />\\n<h4>3.0.0</h4><br />\\n* Breaking change: Deprecate the Call To Action block in favor of Core blocks. This will automatically convert your Call To Action blocks to Core blocks when opening the block editor. The blocks should look mainly the same, but there could be some styling changes, especially if you have custom styling for classes other than \'gb-block-cta\'.<br />\\n* Breaking change: In the Product Features block (child of Pricing block), the settings \'List Border Color\', \'List Border Style\', and \'List Border Width\' are removed. If you set a \'List Border Color\', that color won\'t appear anymore. But the styling for \'List Border Width\' and \'List Border Color\' will be the same, you just won\'t be able to change those via the settings, only Advanced > Additional CSS Classes. This change will only happen when you open the block editor. So if you don\'t open the block editor for the post, your Product Features blocks will stay the same as before.<br />\\n<br />\\n<h4>2.0.0</h4><br />\\n* Breaking change: Deprecate the Button block in favor of Core Buttons block. This will automatically convert your GB Button blocks to Core Buttons blocks when opening the block editor. The buttons should look mainly the same, but there could be some styling changes, especially if you have custom styling for classes other than \'gb-block-button\'.<br />\\n<br />\\n<h4>1.5.5</h4><br />\\n* Fixed: Prevent duplicate blocks in the inserter when another plugin uses a GB category.<br />\\n<br />\\n<h4>1.5.4</h4><br />\\n* Fixed: Fix PHP 8 uksort.<br />\\n* Fixed: Prevent a PHP error on the Newlsetter block.<br />\\n* Changed: Add filter to disable responsive font size controls.<br />\\n<br />\\n<h4>1.5.3</h4><br />\\n* Fixed: Fix a block error with Desktop responsive controls on the Heading and Paragraph blocks.<br />\\n<br />\\n<h4>1.5.2</h4><br />\\n* Changed: NPM tooling overhaul.<br />\\n* Changed: Unignore eslint rules, fix linting.<br />\\n* Fixed: Prevent an error if another plugin incorrectly filters \'admin_body_class\'.<br />\\n<br />\\n<h4>1.5.1</h4><br />\\n* Fixed: Revert changes that modified Profile Box avatar styling.<br />\\n<br />\\n<h4>1.5.0</h4><br />\\n* Changed: Remove Google Analytics entirely.<br />\\n* Fixed: Ensure styles are enqueued.<br />\\n* Fixed: Fix post grid warning.<br />\\n<br />\\n<h4>1.4.0</h4><br />\\n* Added: New Getting Started pages to assist with onboarding.<br />\\n* Added: Optional analytics tracking for responsive styles and layout modal.<br />\\n* Changed: Collections Tab is now the first tab in the layout modal for Sections and Layouts.<br />\\n<br />\\n<h4>1.3.0</h4><br />\\n* Added: Responsive controls for the paragraph and heading core blocks.<br />\\n<br />\\n<h4>1.2.5</h4><br />\\n* Added: block_categories_all filter for WordPress 5.8.<br />\\n* Changed: Replace Font Awesome with SVG files in the Profile Box (aka Author Profile) block, and the Sharing block.<br />\\n* Changed: Ensure the Post Grid block works outside of a post context (such as the WordPress 5.8 widgets screen).<br />\\n* Fixed: Improve accessibility & readability of the Slate Collection colors.<br />\\n<br />\\n<h4>1.2.4</h4><br />\\n* Added: The Post Grid block now allows for multiple categories to be selected.<br />\\n* Changed: The Post Grid block now requires the user to begin typing the name of the category they wish to add, instead of selecting it from a dropdown menu.<br />\\n* Fixed: The Post Grid block has been optimized to reduce load on server and wait times for sites with many categories/pages.<br />\\n* Fixed: The Post Grid Block, when set to show pages, incorrectly used the \\\"Number of items\\\" option to limit the number of pages shown. This has been fixed. The \\\"Number of items\\\" option no longer applies to pages while previewing the block in the editor. The number of pages selected are the number of pages shown. Note that this bug did not affect the frontend, but only what you see in the block editor in wp-admin.<br />\\n* Fixed: The genesis_blocks_allowed_layout_components filter was broken for Layouts (but not Sections) since version 1.2.2 and has been fixed here.<br />\\n<br />\\n<h4>1.2.3</h4><br />\\n* Fixed: Layout link has been moved back to the left of the admin toolbar.<br />\\n<br />\\n<h4>1.2.2</h4><br />\\n* Fixed: Corrected the settings link in the Newsletter Block.<br />\\n* Added: Collection images to layout modal.<br />\\n* Added: Fallback images for section/layout previews that fail to load.<br />\\n* Added: Ability to use section keys to build layouts.<br />\\n<br />\\n<h4>1.2.1</h4><br />\\n* Fixed: The layouts block is no longer left over in the editor if the modal is closed by the user.<br />\\n* Fixed: The layouts button in the Block Editor header toolbar uses a more reliable javascript event to ensure it is always visible.<br />\\n* Fixed: The Post and Page Grid block now shows all pages selected, instead of cutting it off at the number of posts set to show.<br />\\n* New: Added a \\\"Leave a review\\\" button to the settings page.<br />\\n<br />\\n<h4>1.2.0</h4><br />\\n* New: Introducing Collections, a curated suite of pattern designs to quickly build out beautiful pages and full websites.<br />\\n* Added support for migrating Genesis Blocks Pro users.<br />\\n<br />\\n<h4>1.1.1</h4><br />\\n* Fixed an issue for sites migrating from Atomic Blocks where in some cases the migration did not complete due to an error when deactivating the Atomic Blocks plugin.<br />\\n<br />\\n<h4>1.1.0</h4><br />\\n* Added a way to migrate from Atomic Blocks to Genesis Blocks. Update now to learn more!<br />\\n* Fixed issue with border radius in the Accordion block.<br />\\n* Fixed minor bug in the Post Grid block that could cause PHP notices if the block is used in non-standard locations outside of post content.<br />\\n* When using the Advanced Columns block, the inner column block now has a label of Column instead of Advanced Column to make it easier to distinguish from the outer column block that wraps it.<br />\\n* Added a Getting Started page to make it easier to access documentation, discover Genesis themes, and provide us feedback about the plugin. Send us your thoughts!<br />\\n<br />\\n<h4>1.0</h4><br />\\n* Initial release.<br />\\n\",\n    \"screenshots\": \"<ol><li><a href=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-1.png?rev=2368841\\\"><img src=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-1.png?rev=2368841\\\" alt=\\\"Library of pre-designed page layouts\\\"></a><p>Library of pre-designed page layouts</p></li><li><a href=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-2.png?rev=2368843\\\"><img src=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-2.png?rev=2368843\\\" alt=\\\"A pre-designed call-to-action page design\\\"></a><p>A pre-designed call-to-action page design</p></li><li><a href=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-3.png?rev=2368844\\\"><img src=\\\"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-3.png?rev=2368844\\\" alt=\\\"Some of the many blocks included in Genesis Blocks\\\"></a><p>Some of the many blocks included in Genesis Blocks</p></li></ol>\",\n    \"reviews\": \"<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">No Support &amp; No Blocks</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"1 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"1\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/cl1111111111111111111111/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/6f90b201278f105f932d2eff0a7d7d15?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/6f90b201278f105f932d2eff0a7d7d15?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/cl1111111111111111111111/\\\" class=\\\"reviewer-name\\\">cl1111111111111111111111</a> on <span class=\\\"review-date\\\">August 15, 2024</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p>Sadly, installing this added nothing at all. As in .... nothing. An admin panel with an opportunity to enter the subscription code ..... and that\'s it. Tried getting support and got an AI chatbot. Not helpful. Finally was able to get a human via chat who asked what our domain was, and didn\'t see us in some list.  I sent screenshots of our products in the backend at their site, and the subscription code entered on our site ..... and he disappeared. can\'t get a human today. <br /><br />I spent four hours yesterday and today on behalf of my client .... for nothing. I\'m advising client to get their money back.</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Getting better but slowly</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"4 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"4\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/vincentbao/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/267a10065eefb95ff3bbe1e9428539f8?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/267a10065eefb95ff3bbe1e9428539f8?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/vincentbao/\\\" class=\\\"reviewer-name\\\">vincentbao</a> on <span class=\\\"review-date\\\">June 30, 2024</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p>Current version is nice and we recently used in couple of client sites but We wish they increase development and start adding more features so we can achieve advanced layouts too. </p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Installed without consent, bad company</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"1 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"1\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/cybr/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/32150a98514c905566cd53bb6f6d1d3b?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/32150a98514c905566cd53bb6f6d1d3b?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/cybr/\\\" class=\\\"reviewer-name\\\">Sybre Waaijer <small>(Cybr)</small></a> on <span class=\\\"review-date\\\">March 29, 2024</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\">A user installed this plugin on my network without <code>install_plugins</code> capabilities via StudioPress\'s Genesis theme. Today, I got notified that a security fix had been committed for one of the plugins on my network.\\n\\nI inspected the security fix, and practically, a user was permitted to install this backdoor. No wonder it got 100k+ installs while being a most obscure addition to WordPress.\\n\\nThe Genesis theme also installed a couple of Awesome Motive plugins via this, a company that goes against everything WordPress that I wouldn\'t dare to touch with a 10-foot cable. They do this via <code>genesis_do_onboarding_pack_selection()</code>, which checks for <code>manage_options</code>, not <code>install_plugins</code> or <code>is_super_admin()</code>, allowing anyone to hijack an open WordPress Multisite network.\\n\\nI reported these security issues to them two years ago, but obviously, they still haven\'t been resolved. They show no care about your website.\\n\\nMoreover, this plugin pollutes the global namespace with functions like <code>is_heading()</code> (without a namespace). I don\'t know who StudioPress is hiring nowadays, but the senior developers are long gone since its merger with WP Engine.\\n\\nAmateurs. \\n\\nYou shouldn\'t have ignored my previous calls, so enjoy this stain on your record.</div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Good but not professional</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"2 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"2\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/valex83/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/2c88d30c311d5e1b5f3489e0af771fda?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/2c88d30c311d5e1b5f3489e0af771fda?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/valex83/\\\" class=\\\"reviewer-name\\\">valex83</a> on <span class=\\\"review-date\\\">January 10, 2024</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p class=\\\"\\\">I like their blocks but when they upgraded from atomic to genesis I had to change all the blocks for each articles. It took me hours</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Impressed</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"5 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"5\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/peterhann/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/db04077a3741545b2356263933a19b95?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/db04077a3741545b2356263933a19b95?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/peterhann/\\\" class=\\\"reviewer-name\\\">peterhann</a> on <span class=\\\"review-date\\\">September 15, 2023</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p class=\\\"\\\">I\'m so impressed with how smooth and intuitive Genesis Blocks is. Best page builder I\'ve tried. Five stars!</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Great Block Editor for Genesis Theme</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"5 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"5\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/anonymized-21067829/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/743d270345d7948282c03f925a46a6bf?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/743d270345d7948282c03f925a46a6bf?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/anonymized-21067829/\\\" class=\\\"reviewer-name\\\">Anonymous User 21067829 <small>(anonymized_21067829)</small></a> on <span class=\\\"review-date\\\">August 21, 2023</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p class=\\\"\\\">Saved my time when using Gutenberg editor at Genesis theme on my WordPress website.</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Wonderful and simple - Accordion blocks WORK!</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"5 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"5\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/timbearcub/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/a0409596369fdfbd9c54692ba6d8fdd3?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/a0409596369fdfbd9c54692ba6d8fdd3?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/timbearcub/\\\" class=\\\"reviewer-name\\\">timbearcub</a> on <span class=\\\"review-date\\\">February 17, 2023</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p>OK I tried 3/4 of the major critically praised block systems out there, and stupidly I should have just tried the one that was already installed - Genesis Blocks - cos it just works. <br /><br />It\'s simple compared to the fanciness of Spectra or Kadence, but Kadence kept crashing my page and giving errors, and Spectra have decided to make their Accordion block a \'FAQ Block\' and not allow you to add your own paragraphs in (???) and not tell anyone, least of all the WP info page....I deleted it in disgust. Don\'t advertise \'Accordion blocks\' and then not provide them....<br /><br />And Essential Blocks just didn\'t work; the content overlaid when re-collapsed, even on a simple FSE child theme of Automattic\'s 2023! Which is as standard as a theme gets, really.<br /><br />But Genesis might not have all the fancy styling (which in the case of Spectra those default styles overrode my theme CSS, even when set to system default, annoyingly, including ignoring the heading styles?!) but Genesis just happily uses the body typeface, and you can add CSS and it\'s simple to modify the default classes, they make sense.<br /><br />So +1 to Genesis vs the bloaty big boys.</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Crashes sites when upgrade to PHP 8.0</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"1 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"1\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/craftsman/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/dced616f437c4207146a3039cb6c021e?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/dced616f437c4207146a3039cb6c021e?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/craftsman/\\\" class=\\\"reviewer-name\\\"> <small>(craftsman)</small></a> on <span class=\\\"review-date\\\">January 13, 2023</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\"><!-- wp:paragraph -->\\n<p>Worked great for the last couple of years but crashes my sites if I attempt to upgrade PHP to 8.0.</p>\\n<!-- /wp:paragraph -->\\n\\n<!-- wp:paragraph -->\\n<p>I\'ve tried different themes, including the Genesis Sample theme with the same result.</p>\\n<!-- /wp:paragraph --></div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Worst out of StudioPress</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"1 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"1\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span><span class=\\\"star dashicons dashicons-star-empty\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/vitaljik/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/1ddf1c8e1608a1b0e7e962b54b3a484c?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/1ddf1c8e1608a1b0e7e962b54b3a484c?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/vitaljik/\\\" class=\\\"reviewer-name\\\">vitaljik</a> on <span class=\\\"review-date\\\">January 10, 2023</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\">&lt;p&gt;I thought StudioPress was reputable developers, but no. This plugin is not correctly internationalized and is not compatible with multilanguage sites. A shame really.&lt;/p&gt;</div>\\n</div>\\n<div class=\\\"review\\\">\\n\\t<div class=\\\"review-head\\\">\\n\\t\\t<div class=\\\"reviewer-info\\\">\\n\\t\\t\\t<div class=\\\"review-title-section\\\">\\n\\t\\t\\t\\t<h4 class=\\\"review-title\\\">Thank you!</h4>\\n\\t\\t\\t\\t<div class=\\\"star-rating\\\">\\n\\t\\t\\t\\t<div class=\\\"wporg-ratings\\\" aria-label=\\\"5 out of 5 stars\\\" data-title-template=\\\"%s out of 5 stars\\\" data-rating=\\\"5\\\" style=\\\"color:#ffb900;\\\"><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span><span class=\\\"star dashicons dashicons-star-filled\\\"></span></div>\\t\\t\\t\\t</div>\\n\\t\\t\\t</div>\\n\\t\\t\\t<p class=\\\"reviewer\\\">\\n\\t\\t\\t\\tBy <a href=\\\"https://profiles.wordpress.org/inesfreud/\\\"><img alt=\'\' src=\'https://secure.gravatar.com/avatar/266baf67ff8b5304c37444a8fc463109?s=16&#038;d=monsterid&#038;r=g\' srcset=\'https://secure.gravatar.com/avatar/266baf67ff8b5304c37444a8fc463109?s=32&#038;d=monsterid&#038;r=g 2x\' class=\'avatar avatar-16 photo\' height=\'16\' width=\'16\' loading=\'lazy\' decoding=\'async\'/></a><a href=\\\"https://profiles.wordpress.org/inesfreud/\\\" class=\\\"reviewer-name\\\">inesfreud</a> on <span class=\\\"review-date\\\">August 13, 2022</span>\\t\\t\\t</p>\\n\\t\\t</div>\\n\\t</div>\\n\\t<div class=\\\"review-body\\\">This is very helpful blocks plugin. Thank you!</div>\\n</div>\\n\"\n  },\n  \"download_link\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.7.zip\",\n  \"upgrade_notice\": [],\n  \"screenshots\": {\n    \"1\": {\n      \"src\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-1.png?rev=2368841\",\n      \"caption\": \"Library of pre-designed page layouts\"\n    },\n    \"2\": {\n      \"src\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-2.png?rev=2368843\",\n      \"caption\": \"A pre-designed call-to-action page design\"\n    },\n    \"3\": {\n      \"src\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/screenshot-3.png?rev=2368844\",\n      \"caption\": \"Some of the many blocks included in Genesis Blocks\"\n    }\n  },\n  \"tags\": {\n    \"block\": \"block\",\n    \"blocks\": \"blocks\",\n    \"editor\": \"editor\",\n    \"gutenberg\": \"gutenberg\",\n    \"gutenberg-blocks\": \"gutenberg blocks\"\n  },\n  \"versions\": {\n    \"1.0.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.0.0.zip\",\n    \"1.1.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.1.0.zip\",\n    \"1.1.1\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.1.1.zip\",\n    \"1.2.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.0.zip\",\n    \"1.2.1\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.1.zip\",\n    \"1.2.2\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.2.zip\",\n    \"1.2.3\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.3.zip\",\n    \"1.2.4\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.4.zip\",\n    \"1.2.5\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.2.5.zip\",\n    \"1.3.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.3.0.zip\",\n    \"1.4.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.4.0.zip\",\n    \"1.5.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.0.zip\",\n    \"1.5.1\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.1.zip\",\n    \"1.5.2\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.2.zip\",\n    \"1.5.3\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.3.zip\",\n    \"1.5.4\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.4.zip\",\n    \"1.5.5\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.1.5.5.zip\",\n    \"2.0.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.2.0.0.zip\",\n    \"3.0.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.0.0.zip\",\n    \"3.0.1\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.0.1.zip\",\n    \"3.1.0\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.0.zip\",\n    \"3.1.1\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.1.zip\",\n    \"3.1.2\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.2.zip\",\n    \"3.1.3\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.3.zip\",\n    \"3.1.4\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.4.zip\",\n    \"3.1.5\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.5.zip\",\n    \"3.1.6\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.6.zip\",\n    \"3.1.7\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.3.1.7.zip\",\n    \"trunk\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/genesis-blocks.zip\"\n  },\n  \"business_model\": false,\n  \"repository_url\": \"\",\n  \"commercial_support_url\": \"\",\n  \"donate_link\": \"https://studiopress.com\",\n  \"banners\": {\n    \"low\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/banner-772x250.png?rev=2368837\",\n    \"high\": \"https://wpe-plugin-updates.wpengine.com/genesis-blocks/assets/banner-1544x500.png?rev=2368838\"\n  },\n  \"preview_link\": \"\",\n  \"icons\": []\n}","off"),
(150,"acf_first_activated_version","6.6.0","on"),
(151,"acf_site_health","{\"version\":\"6.6.0\",\"plugin_type\":\"PRO\",\"update_source\":\"ACF Direct\",\"activated\":true,\"activated_url\":\"https:\\/\\/nzddevtest2.wpenginepowered.com\",\"license_type\":\"Developer\",\"license_status\":\"inactive\",\"subscription_expires\":\"\",\"wp_version\":\"6.8.3\",\"mysql_version\":\"8.0.42-33\",\"is_multisite\":false,\"active_theme\":{\"name\":\"Twenty Twenty-Five\",\"version\":\"1.3\",\"theme_uri\":\"https:\\/\\/wordpress.org\\/themes\\/twentytwentyfive\\/\",\"stylesheet\":false},\"active_plugins\":{\"advanced-custom-fields-pro\\/acf.php\":{\"name\":\"Advanced Custom Fields PRO\",\"version\":\"6.6.0\",\"plugin_uri\":\"https:\\/\\/www.advancedcustomfields.com\"},\"disable-gutenberg\\/disable-gutenberg.php\":{\"name\":\"Disable Gutenberg\",\"version\":\"3.2.3\",\"plugin_uri\":\"https:\\/\\/perishablepress.com\\/disable-gutenberg\\/\"},\"js_composer\\/js_composer.php\":{\"name\":\"WPBakery Page Builder\",\"version\":\"8.6.1\",\"plugin_uri\":\"https:\\/\\/wpbakery.com\"},\"wp-file-manager\\/file_folder_manager.php\":{\"name\":\"WP File Manager\",\"version\":\"8.0.2\",\"plugin_uri\":\"https:\\/\\/wordpress.org\\/plugins\\/wp-file-manager\"}},\"ui_field_groups\":\"0\",\"php_field_groups\":\"0\",\"json_field_groups\":\"0\",\"rest_field_groups\":\"0\",\"all_location_rules\":[],\"field_groups_with_single_block_rule\":\"0\",\"field_groups_with_multiple_block_rules\":\"0\",\"field_groups_with_blocks_and_other_rules\":\"0\",\"number_of_fields_by_type\":[],\"number_of_third_party_fields_by_type\":[],\"post_types_enabled\":true,\"ui_post_types\":\"4\",\"json_post_types\":\"0\",\"ui_taxonomies\":\"3\",\"json_taxonomies\":\"0\",\"ui_options_pages_enabled\":true,\"ui_options_pages\":\"0\",\"json_options_pages\":\"0\",\"php_options_pages\":\"0\",\"rest_api_format\":\"light\",\"registered_acf_blocks\":\"0\",\"blocks_per_api_version\":[],\"blocks_per_acf_block_version\":[],\"blocks_using_post_meta\":\"0\",\"preload_blocks\":true,\"admin_ui_enabled\":true,\"field_type-modal_enabled\":true,\"field_settings_tabs_enabled\":false,\"shortcode_enabled\":false,\"registered_acf_forms\":\"0\",\"json_save_paths\":1,\"json_load_paths\":1,\"event_first_activated_pro\":1760590372,\"last_updated\":1761683651}","off"),
(152,"acf_version","6.6.0","auto"),
(158,"vc_version","8.6.1","auto"),
(159,"wpb_js_composer_license_activation_notified","yes","auto"),
(160,"wpb_license_errors","a:0:{}","auto"),
(161,"wpb_usage_count","a:2:{s:14:\"vc_column_text\";i:1;s:14:\"vc_empty_space\";i:1;}","auto"),
(162,"WPLANG","","auto"),
(163,"new_admin_email","adam@nzdigital.co.nz","auto"),
(168,"fm_key","cj7PSH31MatfRCNxlVZbIgXvG","auto"),
(169,"filemanager_email_verified_2","yes","auto"),
(170,"acf_pro_license","YToyOntzOjM6ImtleSI7czo3NjoiYjNKa1pYSmZhV1E5TVRBNE56TTNmSFI1Y0dVOVpHVjJaV3h2Y0dWeWZHUmhkR1U5TWpBeE55MHdOaTB5TUNBd01Eb3hNam94T1E9PSI7czozOiJ1cmwiO3M6Mzk6Imh0dHBzOi8vbnpkZGV2dGVzdDcud3BlbmdpbmVwb3dlcmVkLmNvbSI7fQ==","off"),
(177,"wpe-health-check-site-status-result","{\"good\":20,\"recommended\":2,\"critical\":0}","auto"),
(212,"wpe_site_transient_update_themes","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1761731164;s:7:\"checked\";a:1:{s:16:\"twentytwentyfive\";s:3:\"1.3\";}s:8:\"response\";a:0:{}s:9:\"no_update\";a:1:{s:16:\"twentytwentyfive\";a:6:{s:5:\"theme\";s:16:\"twentytwentyfive\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:46:\"https://wordpress.org/themes/twentytwentyfive/\";s:7:\"package\";s:76:\"https://theme-updates.wpengine.com/twentytwentyfive/twentytwentyfive.1.3.zip\";s:8:\"requires\";s:3:\"6.7\";s:12:\"requires_php\";s:3:\"7.2\";}}s:12:\"translations\";a:0:{}}","off"),
(213,"acf_pro_license_status","a:11:{s:6:\"status\";s:6:\"active\";s:7:\"created\";i:0;s:6:\"expiry\";i:0;s:4:\"name\";s:9:\"Developer\";s:8:\"lifetime\";b:1;s:8:\"refunded\";b:0;s:17:\"view_licenses_url\";s:62:\"https://www.advancedcustomfields.com/my-account/view-licenses/\";s:23:\"manage_subscription_url\";s:0:\"\";s:9:\"error_msg\";s:0:\"\";s:10:\"next_check\";i:1761792936;s:16:\"legacy_multisite\";b:1;}","on"),
(216,"filemanager_email_address_5","user7@nzdigital.co.nz","auto"),
(217,"verify_filemanager_fname_5","User","auto"),
(218,"verify_filemanager_lname_5","User","auto"),
(219,"filemanager_email_verified_5","yes","auto"),
(220,"mk_fm_close_fm_help_c_fm","done","auto"),
(222,"wpe_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1761730678;s:8:\"response\";a:1:{s:27:\"js_composer/js_composer.php\";O:8:\"stdClass\":6:{s:4:\"slug\";s:11:\"js_composer\";s:11:\"new_version\";s:5:\"8.7.2\";s:6:\"plugin\";s:27:\"js_composer/js_composer.php\";s:3:\"url\";s:0:\"\";s:7:\"package\";b:1;s:4:\"name\";s:21:\"WPBakery Page Builder\";}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":17:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:3:\"5.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:59:\"https://plugin-updates.wpengine.com/akismet/akismet.5.5.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:67:\"https://plugin-updates.wpengine.com/akismet/assets/icon-128x128.png\";s:2:\"2x\";s:67:\"https://plugin-updates.wpengine.com/akismet/assets/icon-256x256.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:81:\"https://plugin-updates.wpengine.com/akismet/assets/banner-772x250.png?rev=2900731\";s:4:\"high\";s:82:\"https://plugin-updates.wpengine.com/akismet/assets/banner-1544x500.png?rev=2900731\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"6.8.3\";s:8:\"requires\";s:3:\"5.8\";s:12:\"requires_php\";s:3:\"7.2\";s:16:\"requires_plugins\";a:0:{}s:6:\"rating\";i:94;s:11:\"num_ratings\";i:1145;s:15:\"support_threads\";i:5;s:24:\"support_threads_resolved\";i:4;}s:39:\"disable-gutenberg/disable-gutenberg.php\";O:8:\"stdClass\":17:{s:2:\"id\";s:31:\"w.org/plugins/disable-gutenberg\";s:4:\"slug\";s:17:\"disable-gutenberg\";s:6:\"plugin\";s:39:\"disable-gutenberg/disable-gutenberg.php\";s:11:\"new_version\";s:5:\"3.2.3\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/disable-gutenberg/\";s:7:\"package\";s:81:\"https://plugin-updates.wpengine.com/disable-gutenberg/disable-gutenberg.3.2.3.zip\";s:5:\"icons\";a:2:{s:2:\"1x\";s:77:\"https://plugin-updates.wpengine.com/disable-gutenberg/assets/icon-128x128.png\";s:2:\"2x\";s:77:\"https://plugin-updates.wpengine.com/disable-gutenberg/assets/icon-256x256.png\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:3:\"6.8\";s:8:\"requires\";s:3:\"4.9\";s:12:\"requires_php\";s:6:\"5.6.20\";s:16:\"requires_plugins\";a:0:{}s:6:\"rating\";i:100;s:11:\"num_ratings\";i:718;s:15:\"support_threads\";i:1;s:24:\"support_threads_resolved\";i:1;}s:39:\"wp-file-manager/file_folder_manager.php\";O:8:\"stdClass\":17:{s:2:\"id\";s:29:\"w.org/plugins/wp-file-manager\";s:4:\"slug\";s:15:\"wp-file-manager\";s:6:\"plugin\";s:39:\"wp-file-manager/file_folder_manager.php\";s:11:\"new_version\";s:5:\"8.0.2\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/wp-file-manager/\";s:7:\"package\";s:71:\"https://plugin-updates.wpengine.com/wp-file-manager/wp-file-manager.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:75:\"https://plugin-updates.wpengine.com/wp-file-manager/assets/icon-128x128.png\";}s:7:\"banners\";a:2:{s:3:\"low\";s:89:\"https://plugin-updates.wpengine.com/wp-file-manager/assets/banner-772x250.jpg?rev=2491299\";s:4:\"high\";b:0;}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"6.8.1\";s:8:\"requires\";s:3:\"4.0\";s:12:\"requires_php\";s:5:\"5.2.4\";s:16:\"requires_plugins\";a:0:{}s:6:\"rating\";i:94;s:11:\"num_ratings\";i:1407;s:15:\"support_threads\";i:0;s:24:\"support_threads_resolved\";i:0;}}s:7:\"checked\";a:5:{s:34:\"advanced-custom-fields-pro/acf.php\";s:5:\"6.6.0\";s:19:\"akismet/akismet.php\";s:3:\"5.5\";s:39:\"disable-gutenberg/disable-gutenberg.php\";s:5:\"3.2.3\";s:27:\"js_composer/js_composer.php\";s:5:\"8.6.1\";s:39:\"wp-file-manager/file_folder_manager.php\";s:5:\"8.0.2\";}}","off");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES (1,2,"_wp_page_template","page-blank-content.php"),
(10,2,"_edit_lock","1761731108:5"),
(11,2,"_edit_last",2),
(12,2,"_wpb_vc_js_status","true"),
(13,2,"_wpb_vc_editor_type","backend"),
(14,2,"_wpb_post_custom_layout","default");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES (1,1,"2025-10-16 04:16:33","2025-10-16 04:16:33","<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->","Hello world!","","publish","open","open","","hello-world","","","2025-10-16 04:16:33","2025-10-16 04:16:33","",0,"https://nzddevtest.wpenginepowered.com/?p=1",0,"post","",1),
(2,1,"2025-10-16 04:16:33","2025-10-16 04:16:33","[vc_row][vc_column][vc_empty_space height=\"200px\"][vc_column_text css=\"\"]\r\n<h2 style=\"text-align: center;\">Blank Page</h2>\r\n<p style=\"text-align: center;\">Start Building here</p>\r\n[/vc_column_text][vc_empty_space height=\"200px\"][/vc_column][/vc_row]","Home Page","","publish","closed","open","","sample-page","","","2025-10-16 05:06:38","2025-10-16 05:06:38","",0,"https://nzddevtest.wpenginepowered.com/?page_id=2",0,"page","",0),
(4,0,"2025-10-16 04:17:07","2025-10-16 04:17:07","<!-- wp:page-list /-->","Navigation","","publish","closed","closed","","navigation","","","2025-10-16 04:17:07","2025-10-16 04:17:07","",0,"https://nzddevtest.wpenginepowered.com/?p=4",0,"wp_navigation","",0),
(8,2,"2025-10-16 05:01:53","2025-10-16 05:01:53","{\"version\": 3, \"isGlobalStylesUserThemeJSON\": true }","Custom Styles","","publish","closed","closed","","wp-global-styles-twentytwentyfive","","","2025-10-16 05:01:53","2025-10-16 05:01:53","",0,"https://nzddevtest.wpenginepowered.com/?p=8",0,"wp_global_styles","",0),
(14,2,"2025-10-28 20:47:47","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2025-10-28 20:47:47","0000-00-00 00:00:00","",0,"https://nzddevtest7.wpenginepowered.com/?p=14",0,"post","",0),
(15,5,"2025-10-28 20:49:49","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2025-10-28 20:49:49","0000-00-00 00:00:00","",0,"https://nzddevtest7.wpenginepowered.com/?p=15",0,"post","",0);


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint unsigned NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES (1,1,0),
(8,2,0);


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint unsigned NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES (1,1,"category","",0,1),
(2,2,"wp_theme","",0,1);


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES (1,"Uncategorized","uncategorized",0),
(2,"twentytwentyfive","twentytwentyfive",0);


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES (1,1,"nickname","nzddevtest"),
(2,1,"first_name",""),
(3,1,"last_name",""),
(4,1,"description",""),
(5,1,"rich_editing","true"),
(6,1,"syntax_highlighting","true"),
(7,1,"comment_shortcuts","false"),
(8,1,"admin_color","fresh"),
(9,1,"use_ssl",0),
(10,1,"show_admin_bar_front","true"),
(11,1,"locale",""),
(12,1,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(13,1,"wp_user_level",10),
(14,1,"dismissed_wp_pointers",""),
(15,1,"default_password_nag",1),
(16,1,"show_welcome_panel",1),
(17,2,"nickname","chris@nzdigital.co.nz"),
(18,2,"first_name","Chris"),
(19,2,"last_name","Mather"),
(20,2,"description",""),
(21,2,"rich_editing","true"),
(22,2,"syntax_highlighting","true"),
(23,2,"comment_shortcuts","false"),
(24,2,"admin_color","fresh"),
(25,2,"use_ssl",0),
(26,2,"show_admin_bar_front","true"),
(27,2,"locale",""),
(28,2,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(29,2,"wp_user_level",10),
(30,2,"dismissed_wp_pointers","vc_pointers_backend_editor"),
(31,2,"WPE_USER_CREATED_TIME",1760590042),
(34,2,"session_tokens","a:5:{s:64:\"7b169d20be70e3e31524359e6212294a3175cb5e1a29b0fcef93284ccc858bd6\";a:4:{s:10:\"expiration\";i:1761799690;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1760590090;}s:64:\"d56cddc230b3794f0f71c18a66138ec21cf468b2896f8536a1315c1706429992\";a:4:{s:10:\"expiration\";i:1761799694;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1760590094;}s:64:\"daf8897439e34d03a8ac2369648d316d24cfece600a366a3ca5367afed68b78d\";a:4:{s:10:\"expiration\";i:1762129081;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1760919481;}s:64:\"e3675c9f3ddc0c9afdf72bce31f086d6a96f2b48cdb67373476876b5faad7193\";a:4:{s:10:\"expiration\";i:1762894063;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1761684463;}s:64:\"99c16ca5182ed46ccd6a096208bbd318ca4d4a8a11d2d3707fb6a5223c9c2ecd\";a:4:{s:10:\"expiration\";i:1762894070;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1761684470;}}"),
(35,2,"WPE_LAST_LOGIN_TIME",1761684470),
(36,2,"WPE_LOGGED_REQUEST_IDS","a:1:{i:0;s:36:\"e48110c6-301e-45fd-a771-3e02f8d32858\";}"),
(38,2,"wp_dashboard_quick_press_last_post_id",14),
(53,2,"wp_persisted_preferences","a:4:{s:4:\"core\";a:2:{s:26:\"isComplementaryAreaVisible\";b:1;s:24:\"enableChoosePatternModal\";b:1;}s:14:\"core/edit-post\";a:1:{s:12:\"welcomeGuide\";b:0;}s:9:\"_modified\";s:24:\"2025-10-16T05:02:09.257Z\";s:14:\"core/edit-site\";a:1:{s:12:\"welcomeGuide\";b:0;}}"),
(54,2,"_vc_editor_promo_popup","8.6.1"),
(55,2,"wp_user-settings","editor=tinymce"),
(56,2,"wp_user-settings-time",1760590614),
(83,5,"nickname","nzddevtest7-user"),
(84,5,"first_name","User"),
(85,5,"last_name","User"),
(86,5,"description",""),
(87,5,"rich_editing","true"),
(88,5,"syntax_highlighting","true"),
(89,5,"comment_shortcuts","false"),
(90,5,"admin_color","fresh"),
(91,5,"use_ssl",0),
(92,5,"show_admin_bar_front","true"),
(93,5,"locale",""),
(94,5,"wp_capabilities","a:1:{s:13:\"administrator\";b:1;}"),
(95,5,"wp_user_level",10),
(96,5,"dismissed_wp_pointers","vc_pointers_backend_editor"),
(97,5,"session_tokens","a:2:{s:64:\"c0f9be6a1e3c1223354603fb2201cd432e8b0511965f939f0f16fc66910ac7b1\";a:4:{s:10:\"expiration\";i:1761857388;s:2:\"ip\";s:11:\"103.5.75.38\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1761684588;}s:64:\"7a2d41c9f7c3c0d17f560cc45c5c098511a9ed422abbb70c8e2b22ed9bf08fbb\";a:4:{s:10:\"expiration\";i:1761879352;s:2:\"ip\";s:14:\"206.83.102.190\";s:2:\"ua\";s:117:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36\";s:5:\"login\";i:1761706552;}}"),
(98,5,"wp_dashboard_quick_press_last_post_id",15),
(99,5,"wp_persisted_preferences","a:2:{s:4:\"core\";a:1:{s:26:\"isComplementaryAreaVisible\";b:1;}s:9:\"_modified\";s:24:\"2025-10-29T09:36:31.089Z\";}"),
(100,5,"_vc_editor_promo_popup","8.6.1");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES (1,"nzddevtest","$wp$2y$12$w5NB3VXT3m0DYAkIGRZMhOMddUW6.MZULwrbHS.Wx.nO24SSPN1f.","nzddevtest","adam@nzdigital.co.nz","https://nzddevtest7.wpenginepowered.com","2025-10-16 04:16:32","",0,"nzddevtest"),
(2,"chris@nzdigital.co.nz","$wp$2y$12$j05vVaGrWM0eq8DBFOZ1CuS4oSZlJLFLgdXBJ2DtHBIOrYorC5oUe","chrisnzdigital-co-nz","chris@nzdigital.co.nz","","2025-10-16 04:47:22","",0,"Chris Mather"),
(5,"nzddevtest7-user","$wp$2y$12$fNQP2JE6VRqjT.vHV4wX/uh89vr.gQKp8N0Bk9MkVhuITyCsSpDYG","nzddevtest7-user","user7@nzdigital.co.nz","","2025-10-28 20:48:45","",0,"User User");


DROP TABLE IF EXISTS `wp_wpfm_backup`;

CREATE TABLE `wp_wpfm_backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `backup_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `backup_date` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_wpfm_backup` VALUES (1,"backup_2025_10_29_09_48_06-056ef59a","2025-10-29 09:48:06");


SET foreign_key_checks = 1;
